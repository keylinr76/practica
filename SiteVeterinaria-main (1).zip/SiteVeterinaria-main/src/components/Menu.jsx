function Menu() {
  return (
    <div id="menu">
      <a href="#">Inicio</a>
      <a href="#">Serviços</a>
      <a href="#">Contato</a>
      <a href="#">Registro</a>
    </div>
  );
}

export default Menu;
