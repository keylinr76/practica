function Titulo({ texto }) {
  return <h1 id="titulo">{texto}</h1>;
}
export default Titulo;
