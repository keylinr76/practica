import "./Secao.css";

function Secao({ children }) {
  return <div id="secao">{children}</div>;
}

export default Secao;
