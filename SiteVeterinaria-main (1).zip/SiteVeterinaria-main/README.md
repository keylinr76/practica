#Projeto de Programação Web II

Para executar o projeto, faça o clone (git clone) e execute as etapas:

- npm install <-- para instalar as dependências
- code .  <-- para abrir o VSCode
- npm run dev <-- Executa o projeto.

*IMPORTANTE*
O projeto não está com o arquivo firebaseConfig.js então será necessário adicioná-lo.

- Abra o Firebase Console e crie um projeto ou use algum q vocẽ tenha pronto.
- Adicione o aplicativo e inicialize o Firebase conforme orientando pela documentação, adicionando no arquivo src/database/firebaseConfig.js
- Adicione também o Firestore ao projeto e ao arquivo firebaseConfig.js
